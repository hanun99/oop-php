<?php 
class Item{
 var $id;//var int
 //var string
 var $name;
 //var float
 var $price;
 //var int
 var $quantity;
}
 ?>