// <?php
// error_reporting(0);

// $host = "localhost";
// $user = "root";
// $pass = "root";
// $db   = "api";

// $koneksi = mysqli_connect($host,$user,$pass,$db);

// $op = $_GET['op'];
// switch($op){
//     case '':normal();break;
//     default:normal();break;
// }

// function normal(){
//     global $koneksi;
//     $sqll = "select * from pegawai order by id desc";
//     $ql = mysqli_query($koneksi,$sql1);
//     while($r1 = mysqli_fetch_array($q1)){
//         $hasil[] = array(
//             'id' => $r1['id'],
//             'nama' => $r1['nama'],
//             'alamat' => $r1['alamat'],
//             'tgl_input' =>  $r1['tgl_input']
//         )
//     }
// $data['data']['result'] = $hasil;
// echo json_encode($data);
// }












// ?>